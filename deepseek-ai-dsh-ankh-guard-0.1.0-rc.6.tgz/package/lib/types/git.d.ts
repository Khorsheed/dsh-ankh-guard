/**
 * The repository's current HEAD, or null when the directory is not inside a
 * git repository (or git itself is unavailable).
 * @param repoDir - repository directory.
 * @returns the full HEAD sha, or null.
 */
export declare function currentHead(repoDir: string): string | null;
/** Result of a checkpoint commit. */
export type CheckpointCommitResult = {
    ok: true;
    sha: string;
} | {
    ok: false;
    error: string;
};
/**
 * Commit the whole working tree as a checkpoint snapshot (empty commits
 * allowed — a clean tree still records a rollback point).
 * @param repoDir - repository directory.
 * @param message - checkpoint commit message.
 * @returns the new HEAD sha, or a failure reason.
 */
export declare function commitCheckpoint(repoDir: string, message: string): CheckpointCommitResult;
/**
 * Roll the checkout back to a checkpoint commit (discards everything after it).
 * @param repoDir - repository directory.
 * @param sha - the checkpoint commit to reset to.
 * @returns success or a failure reason.
 */
export declare function resetToCheckpoint(repoDir: string, sha: string): {
    ok: boolean;
    error?: string;
};
//# sourceMappingURL=git.d.ts.map