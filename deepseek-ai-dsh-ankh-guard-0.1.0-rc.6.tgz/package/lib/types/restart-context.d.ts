/** The exit agent's durable restart record (written by `schedule-exit`). */
export interface RestartRecord {
    exitAt?: number;
    pid?: number;
    error?: string;
    /** Session id of the agent that scheduled the exit, when known. */
    initiator?: string;
    reportedAt?: number;
}
/** Absolute path of the restart record inside a state directory. */
export declare function restartRecordFile(stateDir: string): string;
/**
 * The pending restart record, or null when none is awaiting a report (absent,
 * unparseable, or already reported).
 * @param stateDir - state directory.
 * @returns the record without `reportedAt`, or null.
 */
export declare function pendingRestartRecord(stateDir: string): RestartRecord | null;
/**
 * The model-visible restart report (Chinese product copy, factual).
 * @param record - the pending restart record.
 * @param canaryPending - whether the restart marker is still present (the
 * watchdog has not yet run/cleared the canary).
 * @returns the report text, or an empty string for a malformed record.
 */
export declare function restartContextText(record: RestartRecord, canaryPending: boolean): string;
/**
 * Acknowledge a restart record so it injects exactly once.
 * @param stateDir - state directory.
 * @param record - the record being reported.
 * @param now - epoch milliseconds of the acknowledgement.
 */
export declare function acknowledgeRestartRecord(stateDir: string, record: RestartRecord, now: number): void;
//# sourceMappingURL=restart-context.d.ts.map