/** One board entry: timestamp, invoking command context, and the description. */
export interface FeedbackEntry {
    ts: number;
    /** The invoking command context, e.g. the CLI verb that produced the anomaly. */
    command: string;
    /** The reproducible, actionable problem description (no secrets or privacy). */
    description: string;
    /** The checkout revision at the time of the report (optional). */
    revision?: string;
}
/** Single-file cap; older entries roll off. */
export declare const MAX_FEEDBACK_ENTRIES = 200;
/** Absolute path of the feedback file (runtime area, sibling of the state dir). */
export declare function feedbackFile(stateDir: string): string;
/**
 * Append one entry (newest kept, capped by {@link MAX_FEEDBACK_ENTRIES}).
 * @param stateDir - the guard state directory (its parent is the runtime home).
 * @param entry - the structured record.
 * @returns whether the append rolled older entries off the cap.
 */
export declare function appendFeedback(stateDir: string, entry: FeedbackEntry): {
    rolled: boolean;
};
/**
 * Read the newest board entries.
 * @param stateDir - the guard state directory.
 * @param limit - how many of the newest entries to return.
 * @returns the entries, newest last.
 */
export declare function readFeedback(stateDir: string, limit?: number): FeedbackEntry[];
//# sourceMappingURL=feedback.d.ts.map