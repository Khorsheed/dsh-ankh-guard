/**
 * Self-restart guard: the hard gate between "the tree is green" and "it is
 * safe to restart the running instance". A self-modifying agent records a
 * green-build credential ONLY after the full build and targeted tests pass;
 * any restart path (launcher canary, the agent's own restart procedure) must
 * consult {@link SelfRestartGuard.verify} and be denied while the credential
 * is missing, stale, or bound to a different HEAD than the checkout.
 *
 * The credential is bound to the git HEAD it was recorded on, so any change
 * after recording invalidates it — a post-hoc or stale credential can never
 * authorize a restart of unverified code. Checkpoints (P2) are plain commits
 * with a guard message; rollback is `git reset --hard` to the checkpoint.
 *
 * @module @deepseek-ai/dsh-ankh-guard
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type GuardState, type VerifyResult } from './state.ts';
/** Plugin configuration. */
export interface SelfRestartGuardConfig {
    /** Credential freshness window in minutes (default 10). */
    maxAgeMinutes?: number;
    /** State directory; defaults to $DSH_HOME/state, else `<cwd>/.dsh-guard-state`. */
    stateDir?: string;
    /** Repository the credential binds to; defaults to the process cwd. */
    repoDir?: string;
    /**
     * How to surface a scheduled restart's record to the agent (default
     * `followup` — fully autonomous: the plugin queues the report as the next
     * turn via `agent.followup`, the official wake-the-agent seam the schedule
     * system uses for reminders, so the agent reports without any user message).
     * `step` rides the first step of whatever turn comes next; `off` disables.
     */
    reportRestartContext?: 'followup' | 'step' | 'off';
    /**
     * How long a non-initiator root agent waits before claiming a restart record
     * whose initiator session has not resumed yet (default 60000 ms). While the
     * initiator is still present in session persistence, its own agent creation
     * is expected within this window; only after it elapses without the initiator
     * appearing does any root agent fall back and claim the record, so a slow
     * session restore never loses the report to a session that resumed first.
     */
    fallbackGraceMs?: number;
}
export declare const Config: z<SelfRestartGuardConfig>;
/** One canary check line. */
export interface CanaryCheck {
    name: string;
    ok: boolean;
    detail: string;
}
/** Canary verdict: the gate plus optional liveness probes. */
export interface CanaryResult {
    ok: boolean;
    checks: CanaryCheck[];
}
/** Result of a checkpoint request. */
export type CheckpointResult = {
    ok: true;
    sha: string;
} | {
    ok: false;
    error: string;
};
/**
 * The guard's public face: what the agent and the launcher consult before and
 * after a self-restart.
 */
export interface SelfRestartGuard {
    /**
     * The gate: is there a fresh, HEAD-bound green credential right now?
     * @returns ok plus a human reason either way.
     */
    verify(): VerifyResult;
    /**
     * Record a green credential for the current HEAD.
     * @param scope - what passed, e.g. 'build+test'.
     * @param options - optional command that produced the green state.
     * @returns the persisted state including the new credential.
     * @throws outside a git repository (no HEAD to bind to).
     */
    record(scope: string, options?: {
        command?: string;
    }): GuardState;
    /**
     * Drop the credential (checkpoint and audit survive).
     * @returns the persisted state without the credential.
     */
    clear(): GuardState;
    /**
     * Read the full state (credential, checkpoint, audit).
     * @returns the loaded state.
     */
    status(): GuardState;
    /**
     * Commit the whole tree as a pre-batch checkpoint and remember it.
     * @param message - batch description; defaults to 'batch snapshot'.
     * @returns the checkpoint commit sha, or a failure reason.
     */
    checkpoint(message?: string): CheckpointResult;
    /**
     * Hard-reset the checkout to a checkpoint commit.
     * @param sha - the checkpoint commit to reset to.
     * @returns success or a failure reason.
     */
    reset(sha: string): {
        ok: boolean;
        error?: string;
    };
    /**
     * Post-restart canary: verify plus an optional port-liveness probe.
     * @param options - optional TCP port that must be listening.
     * @returns one check line per probe; ok only when every check passed.
     */
    canary(options?: {
        port?: number;
    }): Promise<CanaryResult>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        selfRestartGuard: SelfRestartGuard;
    }
}
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "ankh-guard";
/** Required services: the agents registry (root-agent gate for the followup path). */
export declare const inject: string[];
/**
 * Mount the guard service with resolved configuration.
 * @param ctx - plugin context.
 * @param config - validated plugin config.
 */
export declare function apply(ctx: Context, config: SelfRestartGuardConfig): void;
//# sourceMappingURL=index.d.ts.map