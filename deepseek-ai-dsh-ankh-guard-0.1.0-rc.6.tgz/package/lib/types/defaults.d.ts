/**
 * Resolve the state directory: an explicit value wins, then $DSH_HOME/state,
 * then `<cwd>/.dsh-guard-state`.
 * @param configStateDir - plugin/CLI-provided override, or ''/undefined.
 * @returns the state directory.
 */
export declare function resolveStateDir(configStateDir: string | undefined): string;
/**
 * Resolve the repository directory the credential binds to: an explicit value
 * wins, then the process cwd.
 * @param configRepoDir - plugin/CLI-provided override, or ''/undefined.
 * @returns the repository directory.
 */
export declare function resolveRepoDir(configRepoDir: string | undefined): string;
//# sourceMappingURL=defaults.d.ts.map