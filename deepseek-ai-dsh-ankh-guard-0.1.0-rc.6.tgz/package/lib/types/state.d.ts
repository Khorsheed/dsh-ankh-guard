/** A green-build credential: proof that HEAD {@link revision} passed {@link scope} at {@link recordedAt}. */
export interface GuardCredential {
    /** What passed, e.g. 'build' or 'build+test:gui'. */
    scope: string;
    /** The git HEAD revision the green state was produced on. */
    revision: string;
    /** Epoch milliseconds when the credential was recorded. */
    recordedAt: number;
    /** The exact command that produced the green state. */
    command: string;
}
/** A pre-batch snapshot commit the guard can reset back to. */
export interface GuardCheckpoint {
    /** Commit SHA of the checkpoint. */
    revision: string;
    /** Epoch milliseconds when the checkpoint was taken. */
    recordedAt: number;
    /** Human description of the batch the checkpoint guards. */
    message: string;
}
/** Append-only audit trail of state mutations (capped; verify is read-only). */
export interface GuardAuditEntry {
    action: 'record' | 'clear' | 'checkpoint';
    ts: number;
    detail: string;
}
/** The whole persisted state file. */
export interface GuardState {
    credential?: GuardCredential;
    checkpoint?: GuardCheckpoint;
    audit: readonly GuardAuditEntry[];
}
/** The gate's answer. */
export interface VerifyResult {
    ok: boolean;
    reason: string;
}
/** Absolute path of the state file inside a state directory. */
export declare function stateFilePath(stateDir: string): string;
/** A fresh, credential-less state. */
export declare function emptyState(): GuardState;
/**
 * Read the state file; an absent file is an empty state, a malformed one is a
 * loud misconfiguration error (never silently ignored).
 * @param stateDir - directory holding the state file.
 * @returns the parsed state.
 */
export declare function loadState(stateDir: string): GuardState;
/** Persist a state (creates the directory as needed). */
export declare function saveState(stateDir: string, state: GuardState): void;
/** Input for recording a credential. */
export interface RecordInput {
    scope: string;
    revision: string;
    command: string;
}
/**
 * Record a green-build credential bound to {@link RecordInput.revision}.
 * @param stateDir - state directory.
 * @param input - scope, the git HEAD, and the command that went green.
 * @param now - epoch milliseconds (injected for deterministic tests).
 * @returns the persisted state.
 */
export declare function recordCredential(stateDir: string, input: RecordInput, now: number): GuardState;
/**
 * Drop the credential (checkpoint and audit survive).
 * @param stateDir - state directory.
 * @param now - epoch milliseconds (injected for deterministic tests).
 * @returns the persisted state.
 */
export declare function clearCredential(stateDir: string, now: number): GuardState;
/**
 * Persist a pre-batch checkpoint commit reference.
 * @param stateDir - state directory.
 * @param input - the checkpoint commit SHA and its message.
 * @param now - epoch milliseconds (injected for deterministic tests).
 * @returns the persisted state.
 */
export declare function setCheckpoint(stateDir: string, input: {
    revision: string;
    message: string;
}, now: number): GuardState;
/**
 * Answer the gate: a credential is valid only when present, recorded on the
 * CURRENT revision, and younger than {@link maxAgeMinutes}.
 * @param state - the loaded state.
 * @param currentRevision - the git HEAD of the checkout, or null when unavailable.
 * @param now - epoch milliseconds (injected for deterministic tests).
 * @param maxAgeMinutes - freshness window.
 * @returns ok plus a human reason either way.
 */
export declare function verifyCredential(state: GuardState, currentRevision: string | null, now: number, maxAgeMinutes: number): VerifyResult;
//# sourceMappingURL=state.d.ts.map