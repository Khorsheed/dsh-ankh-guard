#!/usr/bin/env node
/** Parsed CLI options; empty stateDir/repoDir mean "use defaults". */
interface CliOptions {
    stateDir: string;
    repoDir: string;
    maxAgeMinutes: number;
    port: number | undefined;
    command: string | undefined;
    message: string | undefined;
    start: string | undefined;
    pid: string | undefined;
    timeoutMs: number | undefined;
    delayMs: number | undefined;
    log: string | undefined;
    foreground: boolean;
    rollback: boolean;
    initiator: string | undefined;
}
/** stdout/stderr sink (injected so tests capture output). */
export interface CliIo {
    stdout: (line: string) => void;
    stderr: (line: string) => void;
}
/** Parse argv into a command, positionals, and options. */
export declare function parse(argv: readonly string[]): {
    error: string;
} | {
    command: string;
    positionals: readonly string[];
    options: CliOptions;
};
/**
 * Run one CLI invocation against the guard state.
 * @param argv - arguments after the subcommand name.
 * @param io - output sinks.
 * @returns the process exit code: 0 ok, 1 gate denied / failure, 2 usage error.
 */
export declare function runCli(argv: readonly string[], io: CliIo): Promise<number>;
export {};
//# sourceMappingURL=cli.d.ts.map