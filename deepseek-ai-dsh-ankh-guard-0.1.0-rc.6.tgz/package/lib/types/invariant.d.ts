/**
 * Package-owned invariant companion for `@deepseek-ai/dsh-ankh-guard`.
 * @module @deepseek-ai/dsh-ankh-guard/invariant
 */
import type { Context } from '@deepseek-ai/cordis';
import type { InvariantInstaller } from '@deepseek-ai/dsh-invariants';
/** Cordis companion plugin name. */
export declare const name = "ankh-guard-invariant";
/** Service required before the companion can reserve package ownership. */
export declare const inject: string[];
/**
 * Owned-data check: the package's state file, when present at the default
 * location, must parse as a well-formed guard state. A malformed file would
 * make the gate unreadable — the credential's revision/recordedAt shape is
 * this package's own contract, so corruption fails loud at load instead of at
 * the moment a restart needs the gate.
 */
export declare const install: InvariantInstaller;
/**
 * Register this package's invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns The installed registration's disposer after setup succeeds.
 */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map